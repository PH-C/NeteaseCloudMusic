import React, {Component} from 'react';
import "./index.less"
import bg1 from '../../../../images/play-controler.png'
import bg2 from '../../../../images/cd-wrapper.png'
export default class Detail extends Component {
    render() {
        let {single} = this.props.location.state?this.props.location.state:{};
        console.log(single);
        return (
            single?<section className="conta">
                <audio src="http://m10.music.126.net/20171019071657/df62d3a3e7125d2e1f534bd1dec1661a/ymusic/0b1f/14d8/4a35/caa99852f95fb2f70ec25be70d2223cc.mp3" preload="none"></audio>
                <div className="backgroundImage"> </div>
                <header className="header">
                    <i className="iconfont icon-left"></i>
                    <div className="m-single">
                        <p>{single.al.name}</p>
                        <p>{single.ar[0].name}</p>
                    </div>
                    <i className="iconfont icon-forward"></i>
                </header>

                <main className="main">
                    <img src={bg1} alt="" className="on-off"/>
                    <div className="disc">
                        <div className="rotate">
                            <img src={bg2} alt="" className="circle"/>
                            <div className="m-song-img">
                                <img src={single.al.picUrl} alt=""/>
                            </div>
                        </div>
                    </div>
                    <div className="operate">
                        <i className="iconfont icon-micro"> </i>
                        <i className="iconfont icon-micro"> </i>
                        <i className="iconfont icon-micro"> </i>
                        <i className="iconfont icon-micro"> </i>
                    </div>
                </main>

                <div className="foot">
                    <div className="plan">
                        <span className="current">00:00</span>
                        <span className="duration">00:00</span>
                        <div className="proBg">
                            <div className="already"></div>
                        </div>
                    </div>
                    <div className="control">
                        <i className="iconfont icon-music"></i>
                        <i className="iconfont icon-music"></i>
                        <i className="iconfont icon-music"></i>
                        <i className="iconfont icon-music"></i>
                        <i className="iconfont icon-music"></i>
                    </div>
                </div>



            </section>:null
        )
    }
}